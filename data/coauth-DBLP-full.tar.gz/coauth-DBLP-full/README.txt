This dataset is derived from the computer science online bibliography DBLP. The
raw data was downloaded from
http://dblp.org/xml/release/
(September 3, 2017 release)

Each simplex corresponds to a publication, and each node in a simplex is an
author on the publication. The timestamp is the year of publication.

The file coauth-DBLP-node-labels.txt maps the node IDs to authors.
